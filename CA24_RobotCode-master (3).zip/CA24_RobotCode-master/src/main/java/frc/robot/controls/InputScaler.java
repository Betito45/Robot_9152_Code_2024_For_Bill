package frc.robot.controls;

public interface InputScaler {
  public double scale(double input);
}
